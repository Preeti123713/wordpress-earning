<?php 
global $wpdb;
global $table_prefix;
// print_r($_POST);
if ( isset( $_POST['submit'] ) ){
    print_r($_POST);
$data= array(
    'name' => $_POST['username'],
    'email'=> $_POST['useremail'],
    'cabs' => $_POST['cab'],
    'datetime'=>date('Y-m-d H:i:s', strtotime(str_replace('-', '/', $_POST['datetime']))),
    'message'=> $_POST['message'] 
);
$table_name = $table_prefix."cab";
$sql= $wpdb->insert($table_name,$data);
if($sql==true){
    echo "<script>alert('data saved'); </script>";
}else{
    echo "<script>alert('failed'); </script>";
}

 } 

?>