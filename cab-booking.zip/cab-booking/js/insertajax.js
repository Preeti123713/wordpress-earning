// insert data into database using ajax
$(document).ready(function() {
  $('#form').submit(function(e) {
    e.preventDefault(); // Prevent the default form submission
    // var id = $(this).data("id");
   var username=  $('input[name=username]').val();
   var email= $('input[name=useremail]').val();
     var cab=  $('#cab option:selected').val();
     var datetime= $('#input').val();
   var  message= $('textarea[name=message]').val();
   var pattern = /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i
   var ajax_url= jQuery('#path').val();
   if(username =="" ){
    alert("username is empty");
   }else if(email == "" || !pattern.test(email)){
    alert("email is empty and not a valid e-mail address");
   }else if(cab == ""){
    alert("Please select at least One option");
    }else if(message == ""){
      alert("message is empty");
    }
        // Collect form data
        var formData = {
            username: username,
            useremail: email,
            cab: cab,
            datetime:  datetime,
            message: message
        };

        // Send AJAX request
        $.ajax({
            type: 'POST',
            url:  ajax_url,// WordPress AJAX URL
            data: formData,
            success: function(response) {
                var res = jQuery.parseJSON(response);
                    if(res.status == 422) {
                        $('#errorMessageUpdate').removeClass('d-none');
                        $('#errorMessageUpdate').text(res.message);

                    }else if(res.status == 200){

                        $('#errorMessageUpdate').addClass('d-none');

                        // alertify.set('notifier','position', 'top-right');
                        // alertify.success(res.message);
                        
                        $('#form')[0].reset();

                    }else if(res.status == 500) {
                        alert(res.message);
                    }
                }
            });
          // }
    });
});


// update the data into database
$('#update').submit(function(e) {
    e.preventDefault(); // Prevent the default form submission
    // var id = $(this).data("id");
    var id =$('#id').val();
   var username=  $('input[name=username]').val();
   var email= $('input[name=useremail]').val();
     var cab=  $('#cab').val();
     var datetime= $('#input').val();
   var  message= $('textarea[name=message]').val();
    // alert(id);
    var ajax_url= jQuery('#path').val();
   
    $.ajax({
        url:ajax_url,
        method:'POST',
        data:{id:id,
            usernameame:username,
            useremail:email,
            cab:cab,
            datetime:datetime,
            message:message
        },
        success:function(response){
            alert(response);
        }
    });
});

// Delete the data into Database 
$(".btn-danger").click(function () {
    var id = $("#id").val();
    var ajax_url = jQuery("#delete").val();
    if (confirm("Are you sure to remove this record ?")) {
      $.ajax({
        url: ajax_url,
        type: "GET",
        data: { id: id },
        error: function () {
          alert("Something is wrong");
        },
        success: function (data) {
          $("#" + id).remove();
          alert("Record removed successfully");
        },
      });
    }
  });

