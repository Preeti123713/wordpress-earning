Max voltage: 0-520VAC
Max current: 40A/line
Usable frequency: 50/60/400HZ
Operating temp.: -40 TO 50C
Leakage current (250V/60HZ): <1mA
Typ. weight, LB(Kg): 3.8(1.7)
Climatic class: 25/100/21
Designed and manufactured in accordance with the following standards:

Designed And Manufactured In Accordance With The Following Standards:
Designed and manufactured in accordance with the following standards:







