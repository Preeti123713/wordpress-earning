<?php
include( '../../../../wp-config.php' );
global $wpdb;
global $table_prefix;

$name     = $_POST[ 'username' ];
$email    = $_POST[ 'useremail' ];
$cabs     = $_POST[ 'cab' ];
$datetime = date( 'Y-m-d H:i:s', strtotime( str_replace( '-', '/', $_POST[ 'datetime' ] ) ) );
$message  = $_POST[ 'message' ];

$table = $table_prefix.'cab';
// Use 'prefix' instead of 'table_prefix'
$sql = "INSERT INTO $table (name,email,cabs,datetime,message) values ('$name','$email','$cabs','$datetime','$message')";
$query = $wpdb->query($sql);

// if ( $query == true ) {
//     echo "<script>alert('Data saved');</script>";
// } else {
//     echo "<script>alert('Failed');</script>";
// }
if($query == true)
{
    $res = [
        'status' => 200,
        'message' => 'Student Created Successfully'
    ];
    echo json_encode($res);
    return;
}
else
{
    $res = [
        'status' => 500,
        'message' => 'Student Not Created'
    ];
    echo json_encode($res);
    return;
}


// $to_email = $_POST[ 'useremail' ];
// $subject = 'Simple Email Testing via PHP';
// $body = 'Hello,nn It is a testing email sent by PHP Script';
// $body1 = 'Hello,nn It is a testing email sent by PHP Script for admin';
// $headers = 'From: nriya5892@gmail.com';

$to =  $_POST[ 'useremail' ]; 
$subject = "Send HTML Email in PHP testing"; 
 
$htmlContent = ' 
    <html> 
    <head> 
        <title>Welcome to testing</title> 
    </head> 
    <body> 
        <h1>Thanks you for joining with us!</h1> 
        <table cellspacing="0" style="border: 2px dashed #FB4314; width: 100%;"> 
            <tr> 
                <th>Name:</th><td>testing</td> 
            </tr> 
            <tr style="background-color: #e0e0e0;"> 
                <th>Email:</th><td>contact@testing.com</td> 
            </tr> 
            <tr> 
                <th>Website:</th><td><a href="http://www.codexworld.com">www.codexworld.com</a></td> 
            </tr> 
        </table> 
    </body> 
    </html>'; 
 
// Set content-type header for sending HTML email 
$headers = "MIME-Version: 1.0" . "\r\n"; 
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n"; 
 
// Additional headers 
$headers .= 'From: nriya5892@gmail.com>' . "\r\n"; 
$headers .= 'Cc: welcome@example.com' . "\r\n"; 
$headers .= 'Bcc: welcome2@example.com' . "\r\n"; 
 
// Send email 
if(mail($to, $subject, $htmlContent, $headers)){ 
    echo 'Email has sent successfully.'; 
}else{ 
   echo 'Email sending failed.'; 
}

if ( mail( $to_email, $subject, $body, $headers ) ) {
    echo "Email successfully sent to $to_email...";
} else {
    echo 'Email sending failed...';
}

$admin = get_option( 'admin_email' );
$headers = 'From: nriya5892@gmail.com';
mail( $admin, $subject, $body1, $headers );


// update the data into database 
$id = $_POST['id'];
$username = $_POST['usernameame'];
$email = $_POST['useremail'];
$cab = $_POST['cab'];
$datetime = date('Y-m-d H:i:s', strtotime(str_replace('-', '/', $_POST['datetime'])));
$message = $_POST['message'];

$sql = "UPDATE wp_cab SET name='$username', email='$email', cabs='$cab', datetime='$datetime' WHERE id=$id";

$query = $wpdb->query($sql);

if ($query === false) {
    echo "Error: " . $sql . "<br>" . esc_sql($wpdb->last_error);
} else {
    echo "Data updated";
}
// Delete The Data Into Database
if(isset($_GET['id']))
{
     $sql = "DELETE FROM wp_cab WHERE id=".$_GET['id'];
     $query = $wpdb->query($sql);

if ($query === false) {
    echo "Error: " . $sql . "<br>" . esc_sql($wpdb->last_error);
} else {
    echo 'Deleted successfully.';;
}
	
}
?>
